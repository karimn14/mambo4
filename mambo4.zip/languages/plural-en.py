# -*- coding: utf-8 -*-
{
'account': ['accounts'],
'book': ['books'],
'is': ['are'],
'man': ['men'],
'miss': ['misses'],
'person': ['people'],
'quark': ['quarks'],
'shop': ['shops'],
'this': ['these'],
'was': ['were'],
'woman': ['women'],
}
